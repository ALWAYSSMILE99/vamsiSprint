import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { SearchComponent } from './search/search.component';
import { AddmoneyComponent } from './addmoney/addmoney.component';
import { TransferComponent } from './transfer/transfer.component';
import { ShowallComponent } from './showall/showall.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'create',
    component: UserComponent
  },
  {
    path: 'search',
    component: SearchComponent
  },
  {
    path: 'addmoney',
    component: AddmoneyComponent
  },
  {
    path: 'transfer',
    component: TransferComponent
  },
  {
    path: 'showall',
    component: ShowallComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
