import { TestBed } from '@angular/core/testing';

import { UserendService } from './userend.service';

describe('UserendService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserendService = TestBed.get(UserendService);
    expect(service).toBeTruthy();
  });
});
