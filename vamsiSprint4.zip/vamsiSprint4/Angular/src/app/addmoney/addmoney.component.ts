import { Component, OnInit } from '@angular/core';
//import data from '../../data/details.json'
import { UserendService } from '../userend.service';

@Component({
  selector: 'app-addmoney',
  templateUrl: './addmoney.component.html',
  styleUrls: ['./addmoney.component.css']
})
export class AddmoneyComponent implements OnInit {
  array=[]
  user: any
  flag=false
  successflag=false
    constructor(private service: UserendService) { }
  
    ngOnInit() {
    }
  
    find(number){
      this.service.findbyid(number).subscribe(data=> {this.array=data})
      this.flag=true    
    }
    update(number, amount){
      this.service.update(number,amount).subscribe(data=>{this.array=data})
      this.successflag=true
    }
}
