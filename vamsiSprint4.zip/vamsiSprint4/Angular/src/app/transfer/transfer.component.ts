import { Component, OnInit } from '@angular/core';
import { UserendService } from '../userend.service';
//import data from '../../data/details.json'


@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {
  array =[];
  successflag=false
  flag = false
  constructor(private service: UserendService) { }

  ngOnInit() {
  }

  find(number1, number2) {
    this.service.findaccounts(number1,number2).subscribe(data=> {this.array=data});
    this.flag = true
  }
  transfer(number1, number2, amount) {
    this.array.splice(0,5);
  this.service.transfer(number1,number2,amount).subscribe(data=>{this.array=data})
  }
}