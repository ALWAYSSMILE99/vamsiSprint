import { Component, OnInit } from '@angular/core';
//import data from '../../data/details.json'
import { UserendService } from '../userend.service';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  array=[];
  flag=false
    constructor(private service: UserendService) { }
  
    ngOnInit() {
    }
  
    setFlag(id)
    {
      this.service.findbyid(id).subscribe(data=>{this.array=data})
      this.flag=true
    }
}

