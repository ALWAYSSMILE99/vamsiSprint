create database bank;

drop table Account;
use bank;

create table Account(accountnumber int(10) primary key auto_increment, name varchar(10), phonenumber bigint(10), emailid varchar(20), balance bigint(10));
select * from Account;